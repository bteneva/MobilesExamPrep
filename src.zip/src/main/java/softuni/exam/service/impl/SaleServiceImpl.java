package softuni.exam.service.impl;

import org.springframework.stereotype.Service;
import softuni.exam.service.SaleService;

import java.io.IOException;

@Service
public class SaleServiceImpl implements SaleService {
    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readSalesFileContent() throws IOException {
        return "";
    }

    @Override
    public String importSales() throws IOException {
        return "";
    }
}
